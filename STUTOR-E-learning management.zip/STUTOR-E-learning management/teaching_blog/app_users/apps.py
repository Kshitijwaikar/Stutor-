from django.apps import AppConfig


class AppUsersConfig(AppConfig):
    name = 'app_users'
